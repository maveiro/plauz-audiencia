# Unificador de Interessados — Sheets/Upload → Supabase

Sistema para consolidar respostas de múltiplos formulários (Google Sheets ou
arquivos CSV/XLS enviados manualmente) — captação de interessados em
ingressos de eventos, por artista — em um único banco de dados, com
sincronização automática, upload de arquivos e interface para cadastrar
novas fontes.

## Como funciona, em uma frase

Você cadastra o link de uma planilha do Google Forms, ou envia um arquivo
CSV/XLS, associando a um evento de um artista; o sistema lê as respostas,
traduz cada coluna para um formato padrão, corrige cidade/estado digitados
livremente, e mantém tudo atualizado em uma tabela única no Supabase — sem
nunca alterar a fonte original.

## Stack

- [Next.js](https://nextjs.org) — interface e API, hospedado na [Vercel](https://vercel.com)
- [Supabase](https://supabase.com) — banco de dados (Postgres) e armazenamento de arquivos (Storage)
- Google Sheets API — leitura das planilhas, via service account
- `papaparse` / `xlsx` (SheetJS) — leitura de arquivos CSV/Excel enviados por upload
- Vercel Cron — sincronização automática periódica (apenas fontes do tipo Google Sheets)

## Setup local

### 1. Pré-requisitos
- Node.js 20+
- Conta no Supabase, Vercel e Google Cloud já criadas
- [Supabase CLI](https://supabase.com/docs/guides/cli) instalado

### 2. Clonar e instalar
```bash
git clone <repo>
cd <repo>
npm install
```

### 3. Variáveis de ambiente
Copie `.env.example` para `.env.local` e preencha (ver `CLAUDE.md` para a
lista completa e o papel de cada variável).

### 4. Banco de dados
```bash
supabase link --project-ref <seu-project-ref>
supabase db push
```
Isso aplica as migrações em `supabase/migrations/` ao seu projeto Supabase,
incluindo a tabela de referência de municípios (`municipios_ref` — ver script
de carga em `docs/PLANO.md`, Fase 1).

### 5. Storage
Crie um bucket no Supabase Storage (ex: `uploads-fontes`) para receber os
arquivos enviados por upload.

### 6. Service account do Google
1. No Google Cloud Console, crie um projeto (ou use um existente) e habilite a
   **Google Sheets API**.
2. Crie uma **service account** e gere uma chave JSON.
3. Preencha `GOOGLE_SERVICE_ACCOUNT_EMAIL` e
   `GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY` no `.env.local` a partir dessa chave.
4. Para cada planilha que for cadastrar, compartilhe-a (permissão de leitura)
   com o e-mail da service account — passo manual, feito uma vez por planilha.

### 7. Rodar localmente
```bash
npm run dev
```

## Estrutura do repositório

```
├── CLAUDE.md                  # instruções do projeto para o agente de IA
├── docs/
│   └── PLANO.md                # roadmap de desenvolvimento, por fase
├── supabase/
│   └── migrations/              # schema do banco, versionado
├── app/                          # rotas Next.js (interface + API)
└── lib/
    ├── readers/                  # leitores de fonte (Google Sheets, upload de arquivo)
    ├── sync/                     # motor de sincronização (agnóstico ao tipo de fonte)
    └── transforms/                # funções de normalização por campo
```

## Conceitos-chave

- **Artista**: quem tem eventos com captação de interessados.
- **Evento**: uma edição/show específico de um artista.
- **Fonte (`source`)**: uma planilha do Google OU um arquivo (CSV/XLS)
  cadastrado, ligado a um evento. Planilhas sincronizam automaticamente;
  arquivos são atualizados por reenvio manual, substituindo a leitura
  anterior da mesma fonte.
- **Dado bruto (`raw_responses`)**: cada linha da fonte, como veio, sem
  tratamento. Nunca é apagado ou sobrescrito de forma destrutiva.
- **Mapeamento (`field_mappings`)**: configuração que diz como traduzir cada
  coluna de cada fonte para o formato padrão.
- **Interessados (`interessados`)**: a tabela final, unificada, com
  validação leve de e-mail/telefone e correção automática de cidade/estado.
- **Sobreposição de público**: como a mesma pessoa pode aparecer em
  interessados de mais de um artista, é possível analisar cruzamento de
  público via uma view dedicada (ver `docs/PLANO.md`, Fase 6).
- **Exclusão**: fontes excluídas usam soft delete (ficam ocultas, mas
  recuperáveis por um tempo) antes de uma limpeza definitiva.

Mais detalhes de arquitetura e decisões de design estão em `CLAUDE.md`.

## Status do projeto

Ver `docs/PLANO.md` para a fase atual e o que falta.
